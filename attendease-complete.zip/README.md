# AttendEase — multi-teacher attendance manager

A local college-demo project built with HTML, CSS, JavaScript, Node.js, Express, and MongoDB.

## Included

- Separate teacher accounts (each teacher only sees their own classes and records)
- Secure password hashing with bcrypt and an HTTP-only login cookie
- Create and delete named classes (FY1, SY1, etc.)
- Add, edit, and remove students; import students from CSV
- Date-wise attendance with Present / Absent / Late statuses
- Requires a status for every active student before saving a register
- Attendance history, class-wise and combined reports, average percentages, low-attendance count, CSV export
- MongoDB models and unique indexes to prevent duplicate roll numbers and duplicate attendance for a student/class/date

## 1. Install prerequisites

Install Node.js LTS and have a MongoDB database available. For the simplest setup, use a free MongoDB Atlas cluster: https://www.mongodb.com/cloud/atlas

In Atlas, create a database user, allow your current IP address in Network Access, and copy the application's connection string. Keep the database password private.

## 2. Configure environment variables

In this project folder, copy `.env.example` and name the copy `.env`.

Open `.env` and set:

```env
MONGODB_URI=mongodb+srv://YOUR_DB_USER:YOUR_DB_PASSWORD@YOUR_CLUSTER/attendease?retryWrites=true&w=majority
JWT_SECRET=replace_with_a_long_random_secret_at_least_32_characters
PORT=3000
SCHOOL_TIMEZONE=Asia/Kolkata
```

Replace the sample MongoDB URI with your actual Atlas URI. If the password has special characters, URL-encode them. Do not share `.env` or upload it to GitHub. `SCHOOL_TIMEZONE` documents the school's timezone; attendance calendar dates are stored as `YYYY-MM-DD` strings so they do not shift because of UTC conversion.

If MongoDB is installed locally instead, you can use `MONGODB_URI=mongodb://127.0.0.1:27017/attendease`.

## 3. Install and run

Open this folder in VS Code, choose Terminal → New Terminal, and run:

```powershell
npm.cmd install
npm.cmd start
```

When you see `AttendEase is running at http://localhost:3000`, open http://localhost:3000 in your browser. The server starts only after it connects to MongoDB.

## 4. First use

1. Choose **Create account** to register the first teacher.
2. Create classes such as FY1 and SY1.
3. Open a class and add students manually or import a CSV.
4. CSV must have a header row with `name` and `rollNumber` columns; `email` is optional. Example:

```csv
name,rollNumber,email
Aditi Sharma,101,aditi@example.com
Rohan Patil,102,rohan@example.com
```

5. Open **Mark attendance**, choose a date, select Present / Absent / Late for every active student, and save.
6. Use **Attendance history** and **Reports & analytics** to review records and export a report.

Every teacher account is independent. Register additional teacher accounts to test the multi-teacher setup. This demo has open teacher registration; it is not an institution-grade deployment. Before putting real student data online, add an institution-controlled account creation process, rate limiting, audit logging, backups, HTTPS, and a security review.

## Notes

- Removing a student deactivates them from future registers while preserving their past attendance for reports.
- Deleting a class permanently deletes its students and attendance records; the app asks for confirmation.
- Attendance percentages count `present` and `late` as attended and use only saved marks in the denominator. Unmarked registers do not count as absent.
- This project has not been externally security-audited and is intended as a learning/college demo.
