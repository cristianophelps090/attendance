const mongoose = require('mongoose');
const studentSchema = new mongoose.Schema({
  teacherId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  classId: { type: mongoose.Schema.Types.ObjectId, ref: 'Classroom', required: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 120 },
  rollNumber: { type: String, required: true, trim: true, maxlength: 40 },
  email: { type: String, trim: true, lowercase: true, default: '' },
  active: { type: Boolean, default: true }
}, { timestamps: true });
studentSchema.index({ classId: 1, rollNumber: 1 }, { unique: true });
module.exports = mongoose.model('Student', studentSchema);
