const mongoose = require('mongoose');
const classroomSchema = new mongoose.Schema({
  teacherId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 80 },
  description: { type: String, trim: true, maxlength: 200, default: '' }
}, { timestamps: true });
classroomSchema.index({ teacherId: 1, name: 1 }, { unique: true });
module.exports = mongoose.model('Classroom', classroomSchema);
