require('dotenv').config();
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const { parse } = require('csv-parse/sync');
const User = require('./models/User');
const Classroom = require('./models/Classroom');
const Student = require('./models/Student');
const Attendance = require('./models/Attendance');
const auth = require('./middleware/auth');

const app = express();
const PORT = Number(process.env.PORT || 3000);
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('ERROR: Set JWT_SECRET in your .env file to a random secret of at least 32 characters.');
  process.exit(1);
}
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const safeUser = user => ({ id: String(user._id), name: user.name, email: user.email });
const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const validDate = date => typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date) && !Number.isNaN(Date.parse(`${date}T12:00:00Z`));
const issueCookie = (res, user) => {
  const token = jwt.sign({ userId: String(user._id) }, process.env.JWT_SECRET, { expiresIn: '8h' });
  res.cookie('attendease_token', token, { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000, path: '/' });
};
async function ownedClass(classId, teacherId) {
  return Classroom.findOne({ _id: classId, teacherId });
}

app.get('/api/health', (req, res) => res.json({ ok: true, database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' }));

app.post('/api/auth/register', asyncRoute(async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (name.length < 2) return res.status(400).json({ error: 'Please enter your full name.' });
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  if (await User.exists({ email })) return res.status(409).json({ error: 'An account with this email already exists. Please log in.' });
  const user = await User.create({ name, email, passwordHash: await bcrypt.hash(password, 12) });
  issueCookie(res, user);
  res.status(201).json({ user: safeUser(user) });
}));
app.post('/api/auth/login', asyncRoute(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const user = await User.findOne({ email });
  if (!user || !(await bcrypt.compare(String(req.body.password || ''), user.passwordHash))) return res.status(401).json({ error: 'Email or password is incorrect.' });
  issueCookie(res, user);
  res.json({ user: safeUser(user) });
}));
app.post('/api/auth/logout', (req, res) => { res.clearCookie('attendease_token', { httpOnly: true, sameSite: 'strict', path: '/' }); res.json({ ok: true }); });
app.get('/api/auth/me', auth, (req, res) => res.json({ user: safeUser(req.user) }));

app.get('/api/classes', auth, asyncRoute(async (req, res) => {
  const classes = await Classroom.find({ teacherId: req.user._id }).sort({ createdAt: 1 }).lean();
  const counts = await Student.aggregate([{ $match: { teacherId: req.user._id, active: true } }, { $group: { _id: '$classId', count: { $sum: 1 } } }]);
  const countMap = new Map(counts.map(x => [String(x._id), x.count]));
  res.json({ classes: classes.map(c => ({ ...c, id: String(c._id), studentCount: countMap.get(String(c._id)) || 0 })) });
}));
app.post('/api/classes', auth, asyncRoute(async (req, res) => {
  const name = String(req.body.name || '').trim();
  const description = String(req.body.description || '').trim();
  if (!name || name.length > 80) return res.status(400).json({ error: 'Class name is required (maximum 80 characters).' });
  try {
    const classroom = await Classroom.create({ teacherId: req.user._id, name, description });
    res.status(201).json({ classroom: { ...classroom.toObject(), id: String(classroom._id), studentCount: 0 } });
  } catch (e) { if (e.code === 11000) return res.status(409).json({ error: 'You already have a class with that name.' }); throw e; }
}));
app.delete('/api/classes/:classId', auth, asyncRoute(async (req, res) => {
  const classroom = await ownedClass(req.params.classId, req.user._id);
  if (!classroom) return res.status(404).json({ error: 'Class not found.' });
  await Promise.all([Attendance.deleteMany({ teacherId: req.user._id, classId: classroom._id }), Student.deleteMany({ teacherId: req.user._id, classId: classroom._id }), classroom.deleteOne()]);
  res.json({ ok: true });
}));

app.get('/api/classes/:classId/students', auth, asyncRoute(async (req, res) => {
  if (!await ownedClass(req.params.classId, req.user._id)) return res.status(404).json({ error: 'Class not found.' });
  const students = await Student.find({ teacherId: req.user._id, classId: req.params.classId, active: true }).sort({ rollNumber: 1, name: 1 }).lean();
  res.json({ students: students.map(s => ({ ...s, id: String(s._id) })) });
}));
app.post('/api/classes/:classId/students', auth, asyncRoute(async (req, res) => {
  if (!await ownedClass(req.params.classId, req.user._id)) return res.status(404).json({ error: 'Class not found.' });
  const name = String(req.body.name || '').trim();
  const rollNumber = String(req.body.rollNumber || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  if (!name || !rollNumber) return res.status(400).json({ error: 'Student name and roll number are required.' });
  try {
    const student = await Student.create({ teacherId: req.user._id, classId: req.params.classId, name, rollNumber, email });
    res.status(201).json({ student: { ...student.toObject(), id: String(student._id) } });
  } catch (e) { if (e.code === 11000) return res.status(409).json({ error: `Roll number ${rollNumber} is already used in this class.` }); throw e; }
}));
app.patch('/api/students/:studentId', auth, asyncRoute(async (req, res) => {
  const student = await Student.findOne({ _id: req.params.studentId, teacherId: req.user._id, active: true });
  if (!student) return res.status(404).json({ error: 'Student not found.' });
  const name = String(req.body.name ?? student.name).trim();
  const rollNumber = String(req.body.rollNumber ?? student.rollNumber).trim();
  const email = String(req.body.email ?? student.email).trim().toLowerCase();
  if (!name || !rollNumber) return res.status(400).json({ error: 'Student name and roll number are required.' });
  student.name = name; student.rollNumber = rollNumber; student.email = email;
  try { await student.save(); } catch (e) { if (e.code === 11000) return res.status(409).json({ error: 'That roll number is already used in this class.' }); throw e; }
  res.json({ student: { ...student.toObject(), id: String(student._id) } });
}));
app.delete('/api/students/:studentId', auth, asyncRoute(async (req, res) => {
  const student = await Student.findOneAndUpdate({ _id: req.params.studentId, teacherId: req.user._id, active: true }, { active: false }, { new: true });
  if (!student) return res.status(404).json({ error: 'Student not found.' });
  // Keep historic attendance so reports remain accurate; inactive students disappear from current registers.
  res.json({ ok: true });
}));
app.post('/api/classes/:classId/students/import', auth, asyncRoute(async (req, res) => {
  if (!await ownedClass(req.params.classId, req.user._id)) return res.status(404).json({ error: 'Class not found.' });
  const csv = String(req.body.csv || '');
  if (!csv.trim() || csv.length > 500000) return res.status(400).json({ error: 'Choose a non-empty CSV file under 500 KB.' });
  let rows;
  try { rows = parse(csv, { bom: true, skip_empty_lines: true, trim: true, relax_column_count: true }); }
  catch { return res.status(400).json({ error: 'Could not read this CSV. Please check its format.' }); }
  if (rows.length < 2) return res.status(400).json({ error: 'CSV must contain a header row and at least one student.' });
  const header = rows[0].map(x => String(x).toLowerCase().trim().replace(/[ _-]/g, ''));
  const nameIndex = header.findIndex(x => ['name', 'studentname', 'fullname'].includes(x));
  const rollIndex = header.findIndex(x => ['rollnumber', 'rollno', 'roll', 'studentid'].includes(x));
  const emailIndex = header.findIndex(x => x === 'email');
  if (nameIndex < 0 || rollIndex < 0) return res.status(400).json({ error: 'CSV needs columns named name and rollNumber (email is optional).' });
  const existing = await Student.find({ teacherId: req.user._id, classId: req.params.classId }).select('rollNumber').lean();
  const rolls = new Set(existing.map(s => s.rollNumber.toLowerCase()));
  const inserts = []; let skipped = 0;
  for (const row of rows.slice(1)) {
    const name = String(row[nameIndex] || '').trim(); const rollNumber = String(row[rollIndex] || '').trim(); const email = emailIndex >= 0 ? String(row[emailIndex] || '').trim().toLowerCase() : '';
    if (!name || !rollNumber || rolls.has(rollNumber.toLowerCase())) { skipped++; continue; }
    rolls.add(rollNumber.toLowerCase()); inserts.push({ teacherId: req.user._id, classId: req.params.classId, name, rollNumber, email });
  }
  if (inserts.length) await Student.insertMany(inserts, { ordered: false });
  res.json({ imported: inserts.length, skipped, message: `Imported ${inserts.length} student(s); skipped ${skipped} blank or duplicate row(s).` });
}));

app.get('/api/classes/:classId/attendance', auth, asyncRoute(async (req, res) => {
  const date = req.query.date;
  if (!validDate(date)) return res.status(400).json({ error: 'Use a date in YYYY-MM-DD format.' });
  if (!await ownedClass(req.params.classId, req.user._id)) return res.status(404).json({ error: 'Class not found.' });
  const [students, records] = await Promise.all([
    Student.find({ teacherId: req.user._id, classId: req.params.classId, active: true }).sort({ rollNumber: 1 }).lean(),
    Attendance.find({ teacherId: req.user._id, classId: req.params.classId, date }).lean()
  ]);
  const byStudent = new Map(records.map(r => [String(r.studentId), r.status]));
  res.json({ date, students: students.map(s => ({ id: String(s._id), name: s.name, rollNumber: s.rollNumber, email: s.email, status: byStudent.get(String(s._id)) || '' })), saved: records.length > 0 });
}));
app.put('/api/classes/:classId/attendance', auth, asyncRoute(async (req, res) => {
  const { date, records } = req.body;
  if (!validDate(date)) return res.status(400).json({ error: 'Use a date in YYYY-MM-DD format.' });
  if (!await ownedClass(req.params.classId, req.user._id)) return res.status(404).json({ error: 'Class not found.' });
  if (!Array.isArray(records)) return res.status(400).json({ error: 'Attendance records are required.' });
  const students = await Student.find({ teacherId: req.user._id, classId: req.params.classId, active: true }).select('_id').lean();
  const allowed = new Set(students.map(s => String(s._id)));
  if (records.length !== students.length || records.some(r => !allowed.has(String(r.studentId)) || !['present', 'absent', 'late'].includes(r.status)) || new Set(records.map(r => String(r.studentId))).size !== students.length) {
    return res.status(400).json({ error: 'Select Present, Absent, or Late for every active student before saving.' });
  }
  const ops = records.map(r => ({ updateOne: { filter: { teacherId: req.user._id, classId: req.params.classId, studentId: r.studentId, date }, update: { $set: { status: r.status, markedBy: req.user._id } }, upsert: true } }));
  if (ops.length) await Attendance.bulkWrite(ops, { ordered: true });
  res.json({ ok: true, saved: records.length, date });
}));
app.get('/api/classes/:classId/reports', auth, asyncRoute(async (req, res) => {
  if (!await ownedClass(req.params.classId, req.user._id)) return res.status(404).json({ error: 'Class not found.' });
  const [students, records] = await Promise.all([
    Student.find({ teacherId: req.user._id, classId: req.params.classId }).lean(),
    Attendance.find({ teacherId: req.user._id, classId: req.params.classId }).lean()
  ]);
  const stats = new Map();
  for (const s of students) stats.set(String(s._id), { studentId: String(s._id), name: s.name, rollNumber: s.rollNumber, active: s.active, total: 0, present: 0, absent: 0, late: 0 });
  for (const r of records) {
    const s = stats.get(String(r.studentId)); if (!s) continue;
    s.total++; s[r.status]++;
  }
  const studentReports = [...stats.values()].map(s => ({ ...s, percentage: s.total ? Math.round(((s.present + s.late) / s.total) * 100) : null })).sort((a, b) => a.rollNumber.localeCompare(b.rollNumber, undefined, { numeric: true }));
  const dates = [...new Set(records.map(r => r.date))].sort().reverse();
  const byDate = dates.map(date => {
    const day = records.filter(r => r.date === date); const present = day.filter(r => r.status === 'present').length; const late = day.filter(r => r.status === 'late').length;
    return { date, total: day.length, present, absent: day.filter(r => r.status === 'absent').length, late, percentage: day.length ? Math.round(((present + late) / day.length) * 100) : 0 };
  });
  res.json({ students: studentReports, dates: byDate });
}));

app.use('/api', (req, res) => res.status(404).json({ error: 'API endpoint not found.' }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.use((err, req, res, next) => {
  console.error(err);
  if (err.name === 'ValidationError') return res.status(400).json({ error: 'Some details are invalid. Please check and try again.' });
  res.status(500).json({ error: 'Something went wrong on the server. Check the terminal for details.' });
});

mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('MongoDB connected.');
    app.listen(PORT, () => console.log(`AttendEase is running at http://localhost:${PORT}`));
  })
  .catch(err => { console.error('Could not connect to MongoDB. Check MONGODB_URI in your .env file.\n', err.message); process.exit(1); });
